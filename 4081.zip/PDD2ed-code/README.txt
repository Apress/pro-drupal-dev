
CODE EXAMPLES FROM PRO DRUPAL DEVELOPMENT, SECOND EDITION
---------------------------------------------------------

To save you some typing, the example modules that are introduced in Pro Drupal
Development, Second Edition are available in this directory.

Module files are organized by chapter.

Install the modules the same way you would your own; that is, place them in
the /sites/all/modules/custom folder of your Drupal installation.

These modules are provided as a courtesy and are not supported in any way.